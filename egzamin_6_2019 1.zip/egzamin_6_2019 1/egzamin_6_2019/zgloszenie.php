<?php
	$zespol = $_POST['zespol'];
	$dys = $_POST['dys'];
	$adres = $_POST['adres'];
	
	$conn = mysqli_connect("localhost","root","");
	if (mysqli_connect_errno()) {
	 echo "Failed to connect to MySQL: " . mysqli_connect_error();
	 exit();}
	mysqli_select_db( $conn,"ratownictwo" );
	$sql = "INSERT INTO zgloszenia (ratownicy_id,dyspozytorzy_id,adres,pilne,czas_zgloszenia) VALUES ('$zespol','$dys','$adres',0,curtime())";
	if (mysqli_query($conn, $sql)) {
	 echo "Success";
	} else {
	 echo "Error" . mysqli_error($conn);
	}
	echo '<br>';
	$sql = "select adres, dyspozytorzy_id from zgloszenia where ratownicy_id=3;";
	$wynik=mysqli_query($conn, $sql);
	if (mysqli_query($conn, $sql)) {
	 echo "Success";
	} else {
	 echo "Error" . mysqli_error($conn);
	}
	echo '<br>';
	while( $row = mysqli_fetch_array($wynik) ){
	echo $row['adres'].' - ';
	echo $row['dyspozytorzy_id'];
	echo '<br>';
	}
	mysqli_free_result($wynik);
	mysqli_close($conn);
?>